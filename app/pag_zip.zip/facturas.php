                <div class="titulo-mod2">
                    <h2>Facturas</h2>
                </div>
                <br/><br/>
                <ul class="fac">
                	<li>PDF</li>
                	<li>XML</li>
                	<li>Fecha</li>
                </ul>
                <ul class="fac bg2">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                <ul class="fac bg1">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                <ul class="fac bg2">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                <ul class="fac bg1">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                <ul class="fac bg2">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                <ul class="fac bg1">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                <ul class="fac bg2">
                	<li>FC120</li>
                	<li>f120.xml</li>
                	<li>14/Agosto/2014</li>
                </ul>
                    