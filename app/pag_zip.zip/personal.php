	<?php include("funciones.php") ?>
    <div class="bienvenidos">
    	BIENVENIDO: -Nombre-
		<span class="text-right"><?php echo date_es("d / F / Y");  ?></span>
    </div>
    <div class="titulo">
                <h2>Personal</h2>
                    <ul>
                        <li><a href="">Alta de personas</a></li>
                        <li><a href="">Consulta de personas</a></li>
                    </ul>
            </div>

    <div class="lAmarilla">
        <h2>Datos personales</h2>
    </div>
    <input type="text" class="form-movimientoR3" placeholder="Nombre">
    <input type="text" class="form-movimientoR3" placeholder="Número de seguro social">
    <input type="text" class="form-movimientoR3" placeholder="Segundo nombre">
    <input type="text" class="form-movimientoR3" placeholder="RFC">
    <input type="text" class="form-movimientoR3" placeholder="Apellido paterno">
    <input type="text" class="form-movimientoR4" placeholder="Fecha de nacimiento">
    <input type="text" class="form-movimientoR3" placeholder="Apellido materno">

    <select class="select-normalR2" name="" id="">
        <option value="">Día</option>
    </select>
    <select class="select-normalR2" name="" id="">
        <option value="">Mes</option>
    </select>
    <select class="select-normalR2" name="" id="">
        <option value="">Año</option>
    </select>

    <select class="select-normalR3" name="" id="">
        <option value="">Estatus</option>
    </select>

    <input type="text" class="form-movimientoR3" placeholder="Puesto">
    <input type="text" class="form-movimientoR3" placeholder="Correo electrónico">
    <input type="text" class="form-movimientoR3" placeholder="Área">

    <div class="lAmarilla">
        <h2>Datos de contacto</h2>
    </div>
    <input type="text" class="form-movimientoR3" placeholder="Teléfono casa">
    <select class="select-normalR3" name="" id="">
        <option value="">Estado</option>
    </select>
    <input type="text" class="form-movimientoR3" placeholder="Teléfono celular">
    <select class="select-normalR3" name="" id="">
        <option value="">Municipio</option>
    </select>
    <input type="text" class="form-movimientoR3" placeholder="Calle y número">
    <input type="text" class="form-movimientoR3" placeholder="Código postal">

    <div class="lAmarilla">
        <h2>Equipo</h2>
    </div>
    <input type="text" class="form-movimientoR3" placeholder="Número de serie laptop">
    <input type="text" class="form-movimientoR3" placeholder="Número de serie celular">
    <input type="text" class="form-movimientoR3" placeholder="Número de serie auto">

    <div class="lAmarilla">
        <h2>Documentos</h2>
    </div>
    <input type="text" class="form-movimientoR5" placeholder="IFE - PDF">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">
    <input type="text" class="form-movimientoR5" placeholder="Comprobante de domicilio">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">
    <input type="text" class="form-movimientoR5" placeholder="Fotografía">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">
    <input type="text" class="form-movimientoR5" placeholder="CURP">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">
    <input type="text" class="form-movimientoR5" placeholder="NSS ">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">
    <input type="text" class="form-movimientoR5" placeholder="RFC">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">
    <input type="text" class="form-movimientoR5" placeholder="Acta de nacimiento">
    <img class="botonBuscar" src="img/botonBuscar.png" alt="">

    <div class="lAmarilla">
        <h2>Acceso</h2>
    </div>
    <p class="subT2R">Acceso</p>
    <img class="puntoVerde" src="img/puntoVerde.png" alt="">
    <input type="text" class="form-movimientoR3" placeholder="Contraseña">
    <input type="checkbox" class="checkboxGoogle">
    <input type="text" class="form-movimientoR42 up" placeholder="Mi correo corporativo está con">
    <img class="puntoVerde" src="img/puntoVerde.png" alt="">
    <input type="text" class="form-movimientoR3" placeholder="Confirmar contraseña">
    <img class="logoGoogle" src="img/logoGoogle.png" alt="">

    <img class="puntoVerde2" src="img/puntoVerde.png" alt="">

    <div class="lAmarilla">
        <h2>Perfil</h2>
    </div>
    <div class="checkboxIzq">
        <ul>
            <li><input type="checkbox" class="checkboxGoogle"></li>
            <li><input type="checkbox" class="checkboxGoogle"></li>
            <li><input type="checkbox" class="checkboxGoogle"></li>
            <li><input type="checkbox" class="checkboxGoogle"></li>
            <li><input type="checkbox" class="checkboxGoogle"></li>
            <li><input type="checkbox" class="checkboxGoogle"></li>
        </ul>
    </div>
        
    <div class="textDer">
        <ul>
            <li><input type="text" class="form-movimientoR43" placeholder="Finanzas"></li>
            <li><input type="text" class="form-movimientoR43" placeholder="Contabilidad"></li>
            <li><input type="text" class="form-movimientoR43" placeholder="Tesorería"></li>
            <li><input type="text" class="form-movimientoR43" placeholder="Recursos Humanos"></li>
            <li><input type="text" class="form-movimientoR43" placeholder="Nómina"></li>
            <li><input type="text" class="form-movimientoR43" placeholder="Parametrización"></li>
        </ul>
    </div>